## New Relic Platform .NET SDK Change Log ##

### v1.0.0.0 - Unreleased ###

* Initial release