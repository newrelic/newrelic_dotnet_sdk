## New Relic Platform .NET SDK Change Log

### v1.0.0.1 - 2/8/2015

* Fixed a bug where failures communicating with New Relic would crash a plugin.

### v1.0.0.0 - 8/29/2014

* Initial release